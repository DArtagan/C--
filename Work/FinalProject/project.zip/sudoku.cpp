//
//	Sudoku Program
//

bool testSudoku();

bool solver() {
	// All things done through functions that come from a header file.
	// Would call a function to populate the classes using user input
	// Runs a series of loops to solve the puzzle
}

bool simulator() {
	// All things done through functions that come from a header file.
	// Ask for seed
	// Would create a viable sudoku puzzle, saves the solution to file for reference by program or user later
	// Allow the user to input values
	// When the puzzle has been attempted, checks the solution
	// On success, congratulates the user 
	// On failure, offers to let them try again or see the solution
}

int main () {
	// If-Else asking the user whether they want to use the simulator or the solver
	// All things done through functions that come from a header file.
}

Include a brief description in pseudocode of how your main (driver) program will operate. 

/*  Wish list  */
// Allow user to save progress
// 