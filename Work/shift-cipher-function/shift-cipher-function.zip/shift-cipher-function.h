//
//
//
#pragma once
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;



void shiftCipher(string& text, int shift);
char shiftBlock(char& text, int shift);

int main();
