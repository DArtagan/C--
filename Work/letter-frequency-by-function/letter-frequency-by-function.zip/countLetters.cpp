//
//  The main routine for a program for finding 
//  the surface area and volume of a square pyramid
//
#include "letter-frequency-by-function.h"

void countLetters(const string& text, const char firstLetter, const char lastLetter, int LetterCounts[])
{
    for(int i(0); i < text.length(); i++) {
        if(text[i] >= firstLetter && text[i] <= lastLetter) {
			LetterCounts[(text[i] - firstLetter)]++;
        }
    }
    return;
}
